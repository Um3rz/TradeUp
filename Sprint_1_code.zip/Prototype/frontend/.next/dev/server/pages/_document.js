var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/e58b1_2136d8ab._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/P04-TradeUp/Prototype/frontend/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/P04-TradeUp/Prototype/frontend/node_modules/next/document.js [ssr] (ecmascript)").exports
