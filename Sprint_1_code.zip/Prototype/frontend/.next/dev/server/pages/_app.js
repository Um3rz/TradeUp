var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__0db8f575._.js")
R.m("[project]/P04-TradeUp/Prototype/frontend/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/P04-TradeUp/Prototype/frontend/node_modules/next/app.js [ssr] (ecmascript)").exports
