globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/e58b1_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_26240113._.js",
    "static/chunks/e58b1_next_dist_compiled_react-dom_302ac78c._.js",
    "static/chunks/e58b1_next_dist_compiled_react-server-dom-turbopack_f8e86fee._.js",
    "static/chunks/e58b1_next_dist_compiled_next-devtools_index_3f9de0ef.js",
    "static/chunks/e58b1_next_dist_compiled_e3fb0cfb._.js",
    "static/chunks/e58b1_next_dist_client_3543e1bc._.js",
    "static/chunks/e58b1_next_dist_860852fd._.js",
    "static/chunks/e58b1_@swc_helpers_cjs_7f8bc8f0._.js",
    "static/chunks/P04-TradeUp_Prototype_frontend_a0ff3932._.js",
    "static/chunks/turbopack-P04-TradeUp_Prototype_frontend_10245ac2._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];