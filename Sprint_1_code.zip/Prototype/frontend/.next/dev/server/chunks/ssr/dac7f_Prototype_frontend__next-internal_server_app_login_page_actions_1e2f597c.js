module.exports = [
"[project]/P04-TradeUp/Prototype/frontend/.next-internal/server/app/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=dac7f_Prototype_frontend__next-internal_server_app_login_page_actions_1e2f597c.js.map