module.exports = [
"[project]/P04-TradeUp/Prototype/frontend/app/favicon.ico.mjs { IMAGE => \"[project]/P04-TradeUp/Prototype/frontend/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/P04-TradeUp/Prototype/frontend/app/favicon.ico.mjs { IMAGE => \"[project]/P04-TradeUp/Prototype/frontend/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/P04-TradeUp/Prototype/frontend/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/P04-TradeUp/Prototype/frontend/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/P04-TradeUp/Prototype/frontend/app/page.tsx [app-rsc] (ecmascript)", (() => {{

throw new Error("An error occurred while generating the chunk item [project]/P04-TradeUp/Prototype/frontend/app/page.tsx [app-rsc] (ecmascript)\n\nCaused by:\n- Expected export to be in eval context \"default\" ImportMap { imports: {}, namespace_imports: {(\"clientProxy\", #22): 1}, reexports: [], references: {ImportMapReference { module_path: \"./page.tsx\", imported_symbol: ModuleEvaluation, annotations: ImportAnnotations { map: {\"__turbopack-helper__\": \"true\", \"turbopack-transition\": \"next-ecmascript-client-reference\"} }, issue_source: Some(IssueSource { source: ResolvedVc(RawVc::TaskCell(846, \"turbopack_core::file_source::FileSource#0\")), range: None }) }, ImportMapReference { module_path: \"./page.tsx\", imported_symbol: Exports, annotations: ImportAnnotations { map: {\"__turbopack-helper__\": \"true\", \"turbopack-transition\": \"next-ecmascript-client-reference\"} }, issue_source: Some(IssueSource { source: ResolvedVc(RawVc::TaskCell(846, \"turbopack_core::file_source::FileSource#0\")), range: None }) }}, has_imports: true, has_exports: false, has_top_level_await: false, strict: false, attributes: {}, full_star_imports: {\"./page.tsx\"}, exports: {} }\n\nDebug info:\n- An error occurred while generating the chunk item [project]/P04-TradeUp/Prototype/frontend/app/page.tsx [app-rsc] (ecmascript)\n- Execution of <ModuleChunkItem as EcmascriptChunkItem>::content_with_async_module_info failed\n- Execution of *EcmascriptChunkItemContent::new failed\n- Execution of EcmascriptModuleContent::new failed\n- Expected export to be in eval context \"default\" ImportMap { imports: {}, namespace_imports: {(\"clientProxy\", #22): 1}, reexports: [], references: {ImportMapReference { module_path: \"./page.tsx\", imported_symbol: ModuleEvaluation, annotations: ImportAnnotations { map: {\"__turbopack-helper__\": \"true\", \"turbopack-transition\": \"next-ecmascript-client-reference\"} }, issue_source: Some(IssueSource { source: ResolvedVc(RawVc::TaskCell(846, \"turbopack_core::file_source::FileSource#0\")), range: None }) }, ImportMapReference { module_path: \"./page.tsx\", imported_symbol: Exports, annotations: ImportAnnotations { map: {\"__turbopack-helper__\": \"true\", \"turbopack-transition\": \"next-ecmascript-client-reference\"} }, issue_source: Some(IssueSource { source: ResolvedVc(RawVc::TaskCell(846, \"turbopack_core::file_source::FileSource#0\")), range: None }) }}, has_imports: true, has_exports: false, has_top_level_await: false, strict: false, attributes: {}, full_star_imports: {\"./page.tsx\"}, exports: {} }");

}}),
"[project]/P04-TradeUp/Prototype/frontend/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/P04-TradeUp/Prototype/frontend/app/page.tsx [app-rsc] (ecmascript)"));
}),
];