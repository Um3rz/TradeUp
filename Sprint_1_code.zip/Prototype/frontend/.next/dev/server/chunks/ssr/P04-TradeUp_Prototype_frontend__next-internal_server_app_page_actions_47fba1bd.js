module.exports = [
"[project]/P04-TradeUp/Prototype/frontend/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=P04-TradeUp_Prototype_frontend__next-internal_server_app_page_actions_47fba1bd.js.map