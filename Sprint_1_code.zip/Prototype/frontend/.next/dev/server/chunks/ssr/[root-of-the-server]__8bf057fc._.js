module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>charts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/P04-TradeUp/Prototype/frontend/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/P04-TradeUp/Prototype/frontend/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2d$debug$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/P04-TradeUp/node_modules/socket.io-client/build/esm-debug/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$lightweight$2d$charts$2f$dist$2f$lightweight$2d$charts$2e$development$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/P04-TradeUp/Prototype/frontend/node_modules/lightweight-charts/dist/lightweight-charts.development.mjs [app-ssr] (ecmascript)");
'use client';
;
;
;
;
function charts() {
    const [tickData, setTickData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const chartContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const chartRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const candlestickSeriesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [candleData, setCandleData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentCandle, setCurrentCandle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // 4 hours in milliseconds
    const CANDLE_INTERVAL = 4 * 60 * 60 * 1000;
    const getCandleStartTime = (timestamp)=>{
        return Math.floor(timestamp / CANDLE_INTERVAL) * CANDLE_INTERVAL;
    };
    const initializeChart = ()=>{
        if (!chartContainerRef.current) return;
        const chart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$lightweight$2d$charts$2f$dist$2f$lightweight$2d$charts$2e$development$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createChart"])(chartContainerRef.current, {
            width: chartContainerRef.current.clientWidth,
            height: 500,
            layout: {
                background: {
                    color: 'transparent'
                },
                textColor: 'hsl(var(--foreground))'
            },
            grid: {
                vertLines: {
                    color: 'hsl(var(--border))'
                },
                horzLines: {
                    color: 'hsl(var(--border))'
                }
            },
            timeScale: {
                timeVisible: true,
                secondsVisible: false,
                borderColor: 'hsl(var(--border))'
            },
            rightPriceScale: {
                borderColor: 'hsl(var(--border))'
            }
        });
        const candlestickSeries = chart.addCandlestickSeries({
            upColor: '#22c55e',
            downColor: '#ef4444',
            borderVisible: false,
            wickUpColor: '#22c55e',
            wickDownColor: '#ef4444'
        });
        chartRef.current = chart;
        candlestickSeriesRef.current = candlestickSeries;
        // Handle resize
        const resizeObserver = new ResizeObserver((entries)=>{
            if (chartRef.current && chartContainerRef.current) {
                chartRef.current.applyOptions({
                    width: chartContainerRef.current.clientWidth
                });
            }
        });
        resizeObserver.observe(chartContainerRef.current);
        return ()=>{
            resizeObserver.disconnect();
        };
    };
    const processTickData = (tickData)=>{
        // Extract price from tick data - adjust this based on your actual tick data structure
        const tickTime = new Date().getTime(); // Use current time or tickData.timestamp if available
        const tickPrice = tickData.price || tickData.last || tickData.close || Math.random() * 100 + 50; // Fallback for testing
        const candleStartTime = getCandleStartTime(tickTime);
        // Check if this tick belongs to current candle or new one
        if (!currentCandle || currentCandle.time !== candleStartTime) {
            // Start new candle
            const newCandle = {
                time: candleStartTime / 1000,
                open: tickPrice,
                high: tickPrice,
                low: tickPrice,
                close: tickPrice
            };
            if (currentCandle) {
                // Add completed candle to history
                setCandleData((prev)=>[
                        ...prev,
                        currentCandle
                    ]);
            }
            setCurrentCandle(newCandle);
        } else {
            // Update current candle
            setCurrentCandle((prev)=>({
                    ...prev,
                    high: Math.max(prev.high, tickPrice),
                    low: Math.min(prev.low, tickPrice),
                    close: tickPrice
                }));
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        initializeChart();
        const socket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2d$debug$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["io"])("http://localhost:3001/ws");
        socket.emit("subscribeSymbol", "HBL");
        socket.on("tickUpdate", (data)=>{
            setTickData(data);
            processTickData(data);
        });
        return ()=>{
            socket.close();
            if (chartRef.current) {
                chartRef.current.remove();
            }
        };
    }, []);
    // Update chart when candle data changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (candlestickSeriesRef.current && candleData.length > 0) {
            candlestickSeriesRef.current.setData(candleData);
        }
    }, [
        candleData
    ]);
    // Update chart when current candle changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (candlestickSeriesRef.current && currentCandle) {
            const allData = [
                ...candleData,
                currentCandle
            ];
            candlestickSeriesRef.current.setData(allData);
        }
    }, [
        currentCandle,
        candleData
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                children: "Live 4-Hour Candlestick Chart - HBL"
            }, void 0, false, {
                fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                lineNumber: 145,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: chartContainerRef,
                style: {
                    width: '800px',
                    height: '400px',
                    border: '1px solid #ccc'
                }
            }, void 0, false, {
                fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                lineNumber: 146,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginTop: '20px'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Raw Tick Data:"
                            }, void 0, false, {
                                fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                                lineNumber: 148,
                                columnNumber: 20
                            }, this),
                            " ",
                            tickData ? JSON.stringify(tickData) : "Waiting for data..."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                        lineNumber: 148,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Current Candle:"
                            }, void 0, false, {
                                fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                                lineNumber: 149,
                                columnNumber: 20
                            }, this),
                            " ",
                            currentCandle ? JSON.stringify(currentCandle) : "No candle yet"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                        lineNumber: 149,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$P04$2d$TradeUp$2f$Prototype$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Completed Candles:"
                            }, void 0, false, {
                                fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                                lineNumber: 150,
                                columnNumber: 20
                            }, this),
                            " ",
                            candleData.length
                        ]
                    }, void 0, true, {
                        fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                        lineNumber: 150,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
                lineNumber: 147,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/P04-TradeUp/Prototype/frontend/app/charts/page.tsx",
        lineNumber: 144,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__8bf057fc._.js.map