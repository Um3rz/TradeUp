module.exports = [
"[project]/P04-TradeUp/Prototype/frontend/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=dac7f_Prototype_frontend__next-internal_server_app__not-found_page_actions_1c6c5be4.js.map