module.exports = [
"[project]/P04-TradeUp/Prototype/frontend/.next-internal/server/app/buy/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=dac7f_Prototype_frontend__next-internal_server_app_buy_page_actions_b230be6b.js.map