module.exports = [
"[project]/P04-TradeUp/Prototype/frontend/.next-internal/server/app/charts/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=dac7f_Prototype_frontend__next-internal_server_app_charts_page_actions_ed0dd954.js.map