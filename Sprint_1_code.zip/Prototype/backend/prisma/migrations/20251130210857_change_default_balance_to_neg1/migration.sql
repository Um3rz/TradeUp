-- AlterTable
ALTER TABLE "User" ALTER COLUMN "balance" SET DEFAULT -1;
